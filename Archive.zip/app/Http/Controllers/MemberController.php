<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use App\Models\User;

class MemberController extends Controller
{
    public function index()
    {

       return view('auth/member-form');
    }

    public function create(Request $request)
    {


        if ($request->referral_code && $request->referral_code == "0090") {
                

            // transform storage link to public link
            $file_name = $request->file('passport')->store('public/img');
            $name_bits = explode("/", $file_name);
            $link_name = implode("/", ["storage", $name_bits[1], $name_bits[2]]);


            $member = new User;
            $member->firstname = $request->firstname;
            $member->lastname = $request->lastname;
            $member->middlename = $request->middlename;
            $member->phone = $request->phone;
            $member->email = $request->email; 
            $member->password = Hash::make($request->password);
            $member->referrer_name = $request->referrer_name;
            $member->kin_name = $request->kin_name;
            $member->kin_phone = $request->kin_phone;
            $member->account_number = $request->account_number;
            $member->bank = $request->bank;
            $member->date_of_payment = $request->date_of_payment;
            $member->agree_100k = $request->agree_100k;
            $member->agree_10_percent = $request->agree_10_percent;
            $member->agree_no_advert = $request->agree_no_advert;
            $member->agree_no_refund = $request->agree_no_refund;
            $member->agree_not_liable = $request->agree_not_liable;
            $member->agree_required_info = $request->agree_required_info;
            $member->agree_terms = $request->agree_terms;
            $member->passport_url = $link_name;

            $member->referral_code = $request->referral_code? $request->referral_code : Str::random(10);


            $res = $member->save();

            dd($res);

        } else {
            
            return back()->with('error', 'Invalid referral code');
        }
        
        
        

    }
}


     
  
      

// referrer_name
// kin_name
// kin_phone
// account_number
// bank
// date_of_payment
// agree_100k
// agree_10_percent
// agree_no_advert
// agree_no_refund
// agree_not_liable
// agree_required_info
// agree_terms